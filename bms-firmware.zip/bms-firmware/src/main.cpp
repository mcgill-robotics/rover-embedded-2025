#include <Arduino.h>
#include <Wire.h>
#include <stdio.h>
#include <stdlib.h>

#include "Registers.h"

//mV, per cell over and undervoltage thresholds initials (don't want to change?)
#define OV_THRESH 4500
#define UV_THRESH 3500

//BMS I2C Addresses
#define BMS1_ADDRESS 0x08
//#define BMS2_ADDRESS (need the actual address)

// I2C pins for ESP32 (not sure what they are on the new BMS chip that kathelina is designing, could be SDA = 4 SCL = 5)
#define SDA_PIN 21 //only for one, need a second one
#define SCL_PIN 22
//Global 'values' of bms (not real) to practice serial.println to jetson
const int bms_values[10] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};

// put function declarations here:
void upload_setpoints(byte);
void read_setpoints(byte);
int readRegister(byte); // byte is the address, int would be the data to write to the register (ie the setpoints for the first interaction)
int writeRegister(byte, int);


void setup() {
  // put your setup code here, to run once:
  Serial.begin(9600);
    while (!Serial) {
    ; // Wait for the serial port to be ready
  }
  Serial.println("Setup start");
  for (int i = 0; i<10; i++){
    Serial.println(bms_values[i]);
  }
}

void loop() {
  // put your main code here, to run repeatedly:
}

// put function definitions here:
